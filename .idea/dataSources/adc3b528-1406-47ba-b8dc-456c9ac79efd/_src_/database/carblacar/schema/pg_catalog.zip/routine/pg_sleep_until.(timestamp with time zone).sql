CREATE FUNCTION pg_sleep_until (timestamp with time zone) RETURNS void
	LANGUAGE sql
AS $$
select pg_catalog.pg_sleep(extract(epoch from $1) operator(pg_catalog.-) extract(epoch from pg_catalog.clock_timestamp()))
$$
