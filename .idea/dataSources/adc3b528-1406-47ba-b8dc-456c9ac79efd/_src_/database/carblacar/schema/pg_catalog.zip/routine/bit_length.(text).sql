CREATE FUNCTION bit_length (text) RETURNS integer
	LANGUAGE sql
AS $$
select pg_catalog.octet_length($1) * 8
$$
