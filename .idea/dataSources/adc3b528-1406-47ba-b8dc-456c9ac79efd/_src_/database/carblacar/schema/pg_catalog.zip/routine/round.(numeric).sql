CREATE FUNCTION round (numeric) RETURNS numeric
	LANGUAGE sql
AS $$
select pg_catalog.round($1,0)
$$
